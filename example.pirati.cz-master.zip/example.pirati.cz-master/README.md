# example.pirati.cz

[![Build Status](https://api.travis-ci.org/pirati-web/praha.pirati.cz.svg?branch=gh-pages)](https://travis-ci.org/pirati-web/praha.pirati.cz)

[Návod](https://github.com/pirati-web/jekyll-theme-pirati/blob/master/USAGE.md) na nastavení a používaní jednoduchého webu nad `jekyll-theme-pirati`
