---
title: Kandidátka na radnici
uid: radnice
# number: 13 # číslo kandidátky odkomentujte až bude známé
leader:
  uid: prvni.leader
  age: 31
  profession: knihovník
  party: Piráti
  description: expert na skoky # zobrazuje se v komunalni-volby

head: # čelo kandidátky (bez leadera) / lidé kteří mají fotku a _people/jmeno.md
  - uid: mistni.predseda
    profession: knihovník
    description: expert na skoky
    party: bez politické příslušnosti
  - uid: jakub.pirat
    profession: knihovník
  - uid: aktivni.priznivec
    age: 63
    profession: zametač
    description: expert přes dětská hřiště
    party: Evropani.cz
tail: # zbytek kandidatky
      # jedinná povinná položka je name zbytek můžete vynechat
      # věk se uvádí k poslednímu dni voleb
  - name: Mudr. Místní Dkotor
    age: 49
    profession: obvodní lékař
    party: bez politické příslušnosti
  - name: Tomáš Šťoural
    age: 19
    profession: student
    party: Piráti
  - uid: mistni.predseda
    profession: knihovník
    description: expert na skoky
    party: bez politické příslušnosti
note: # poznámka pod kanidátku
    Primárky stále běží. Zbytek kandidátky zveřejníme, jakmile doběhnou.
---
