---
title: Kandidátka senát
uid: senat
leader:
    uid: prvni.leader
    age: 31
    profession: knihovník
    party: Piráti
    description: expert na skoky # zobrazuje se v komunalni-volby
number: 4 # číslo kandidátky odkomentujte až bude známé
---
