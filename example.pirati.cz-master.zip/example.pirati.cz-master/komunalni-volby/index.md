---
layout: communal-elections
title: Komunální volby v Praze
campaignCategoryUid: praha2018
candidateListUid: radnice # uid z `_candidates/radnice.md`
---

Úvodní text např. vysvětlení koalice, podpory.

> "Vyhrajeme volby," říká leader.

