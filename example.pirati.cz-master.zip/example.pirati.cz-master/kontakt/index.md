---
layout: contacts
description: Pirátská strana v XY je otevřená a ráda přivítá dobrovolníky a odpoví na dotazy kritiků.
keywords: kontakt, adresa, telefon, mail, facebook, kde najdu, kde jsou
# Pokud nechcete, aby se zobrazovalo kontaktní místo, můžete odkomentovat následující řádek:
# noresidence: yes
contentSize: default
# Pokud chcete aby obsah a tabulka kontaktů měly stejné proporce, můžete použít:
# contentSize: even
---

<div class="o-section-header o-section-header--indented">
  <h1 class="t-h2-alt">Přidejte se</h1>
</div>

Zajámá vás co piráti dělají? Ozvěte se Jakubu Pirátovy nebo přijďte k nám
na schůzi kterou pořádáme v XY.

Chcete přístup k pirátskym systémum? Regitrujte se na nalodění. TODO odkaz.

Financí dary můžete posílat na [dary](https://dary.pirati.cz).
Pokud chcete darovat přimo naší MS poradtě se s XY


Strany našeho kraje jsou TODO.

