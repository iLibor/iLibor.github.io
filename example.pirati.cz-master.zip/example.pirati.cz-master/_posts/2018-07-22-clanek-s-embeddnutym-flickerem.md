---
date: 2018-07-22
category: blog
tags: tag1 tag2
title: Článek s embeddnutým flickerem
author: Jmeno Prijmeni
authorId: jakub.pirat    # uid nekoho z _people (nepoviné)
image: posts/obrazek-u-tohoto-postu.jpg
---

<a data-flickr-embed="true" data-context="true"  href="https://www.flickr.com/photos/pirati/42622817781/in/album-72157669846095718/" title="Mikuláš Ferjenčík"><img src="https://farm2.staticflickr.com/1760/42622817781_34bb2a5f76_c.jpg" width="800" height="534" alt="Mikuláš Ferjenčík"></a><script async src="//embedr.flickr.com/assets/client-code.js" charset="utf-8"></script>
