---
category: CLANKY
title: Nadpis článku
date: 2018-03-14T12:00:00.000Z
author: Jmeno Prijmeni
authorId: jmeno.prijmeni    # uid nekoho z _people
image: posts/obrazek-u-tohoto-postu.jpg
tags:
  - tag 1
  - tag 2
---

Posty musí být každý ve vlastním souboru pojmenovaném datumem a nejakym nazvem, například _posts/2018-03-14-slavime-pi-day.md. Tento název se pak objeví v adrese, tedy xxx.pirati.cz/aktuality/slavime-pi-day.html.

Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nulla accumsan, elit
sit amet varius semper, nulla mauris mollis quam, tempor suscipit diam nulla vel
leo. Fusce nibh. Etiam dictum tincidunt diam. Suspendisse nisl. Ut enim ad minim
veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
consequat. Sed elit dui, pellentesque a, faucibus vel, interdum nec, diam. Etiam
dui sem, fermentum vitae, sagittis id, malesuada in, quam. Fusce tellus. Donec
ipsum massa, ullamcorper in, auctor et, scelerisque sed, est. Class aptent
taciti sociosqu ad litora torquent per conubia nostra, per inceptos hymenaeos.
Fusce aliquam vestibulum ipsum. Vestibulum erat nulla, ullamcorper nec, rutrum
non, nonummy ac, erat. Ut enim ad minima veniam, quis nostrum exercitationem
ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur?

Nullam lectus justo, vulputate eget mollis sed, tempor sed magna. Etiam commodo
dui eget wisi. Cras elementum. Etiam dictum tincidunt diam. Aliquam erat
volutpat. Duis sapien nunc, commodo et, interdum suscipit, sollicitudin et,
dolor. Aliquam erat volutpat. Etiam ligula pede, sagittis quis, interdum
ultricies, scelerisque eu. Cras elementum. Vestibulum fermentum tortor id mi.
Etiam quis quam. Mauris elementum mauris vitae tortor. Fusce tellus. Integer
rutrum, orci vestibulum ullamcorper ultricies, lacus quam ultricies odio, vitae
placerat pede sem sit amet enim. Ut enim ad minima veniam, quis nostrum
exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi
consequatur?

Quisque porta. Nulla pulvinar eleifend sem. Praesent id justo in neque elementum
ultrices. Aliquam erat volutpat. Etiam dictum tincidunt diam. Itaque earum rerum
hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias
consequatur aut perferendis doloribus asperiores repellat. Fusce tellus odio,
dapibus id fermentum quis, suscipit id erat. Vestibulum erat nulla, ullamcorper
nec, rutrum non, nonummy ac, erat. Nulla est. Donec iaculis gravida nulla.

Vivamus porttitor turpis ac leo. Aliquam ante. Nullam justo enim, consectetuer
nec, ullamcorper ac, vestibulum in, elit. Maecenas libero. Aliquam ornare wisi
eu metus. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Duis
bibendum, lectus ut viverra rhoncus, dolor nunc faucibus libero, eget facilisis
enim ipsum id lacus. Nunc auctor. Fusce dui leo, imperdiet in, aliquam sit amet,
feugiat eu, orci. Vestibulum fermentum tortor id mi. In dapibus augue non
sapien. Mauris elementum mauris vitae tortor. Vivamus luctus egestas leo.
Maecenas ipsum velit, consectetuer eu lobortis ut, dictum at dui. Mauris dictum
facilisis augue. Aenean placerat. Nullam lectus justo, vulputate eget mollis
sed, tempor sed magna. Nullam feugiat, turpis at pulvinar vulputate, erat libero
tristique tellus, nec bibendum odio risus sit amet ante. Fusce wisi. Phasellus
enim erat, vestibulum vel, aliquam a, posuere eu, velit.

Cras elementum. Integer vulputate sem a nibh rutrum consequat. Integer tempor.
Donec iaculis gravida nulla. Donec quis nibh at felis congue commodo. Vivamus
porttitor turpis ac leo. Vivamus luctus egestas leo. Donec ipsum massa,
ullamcorper in, auctor et, scelerisque sed, est. Phasellus rhoncus. Nam sed
tellus id magna elementum tincidunt. Neque porro quisquam est, qui dolorem ipsum
quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi
tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Duis
ante orci, molestie vitae vehicula venenatis, tincidunt ac pede.

- - -
