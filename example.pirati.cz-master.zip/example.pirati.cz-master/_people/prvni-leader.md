---
uid: prvni.leader
name:     První Leader  	# běžně používáné jméno
titles:
  before: Bc.
  after: DiS.
category:
  - clenove
  - kandidat-obec
ordclenove: 3
description: mistr světa ve skoku pro něco # zobrazuje se v lide
profession: knihovník
img: people/jakub-pirat.jpg # zakomentuj radek dokud není fotka
mail:
  - prvni.leader@pirati.cz
profiles:
  facebook: https://www.facebook.com/uzivatel.na.fb  # pokud nema, staci smazat tuto radku
  googleplus: https://plus.google.com/+uzivatel.na.googleplus
  twitter: https://twitter.com/uzivatel.na.twitteru
  flickr:		  https://www.flickr.com/search/?user_id=68741528%40N03&sort=date-taken-desc&view_all=1&text=ond%C5%99ej%20profant
---

Jméno Příjmení (*1. ledna 1900) je to a to, a tak dál. Sem patří představení člověka, několik odstavců.

**Vzdělání/práce:** Studoval něco, teď dělá něco.

**Politik:** Třeba čemu se věnuje.

**Osobní:** Něco dalšího, měnit dle libosti, tady může být cokoliv. Není nutné, aby byly nadpisy tučně. Fakt jak chcete.

