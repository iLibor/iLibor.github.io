---
uid: mistni.predseda
name:     Místní Předseda  	# běžně používáné jméno
titles:
  before:
  after:
category:
  - clenove
  - pms
ordpms: 1
ordclenove: 1
description: mistr světa ve skoku pro něco # zobrazuje se v lide
#img: people/mistni-predseda.jpg # zakomentuj radek dokud není fotka
mail:
  - mistni.predsedat@pirati.cz
profiles:
  facebook: https://www.facebook.com/uzivatel.na.fb  # pokud nema, staci smazat tuto radku
  googleplus: https://plus.google.com/+uzivatel.na.googleplus
  twitter: https://twitter.com/uzivatel.na.twitteru
---

Jméno Příjmení (*1. ledna 1900) je to a to, a tak dál. Sem patří představení člověka, několik odstavců.

**Vzdělání/práce:** Studoval něco, teď dělá něco.

**Politik:** Třeba čemu se věnuje.

**Osobní:** Něco dalšího, měnit dle libosti, tady může být cokoliv. Není nutné, aby byly nadpisy tučně. Fakt jak chcete.

