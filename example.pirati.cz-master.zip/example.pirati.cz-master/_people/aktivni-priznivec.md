---
uid: aktivni.priznivec
name:     Aktivní Příznivec  	# běžně používáné jméno
titles:
  before: PhDr.
  after:
category:
  - priznivci
  - kandidat-obec
description: kandidát do senátu # zobrazuje se v lide
#img: people/aktivni-priznivec.jpg # zakomentuj radek dokud není fotka
asistenti:
  - name: Mgr. Věra Marušiaková
    position: Asitentka
    mail: vera.marusiakova@pirati.cz
mail:
  - aktivni.priznivec@pirati.cz
profiles:
  facebook: https://www.facebook.com/uzivatel.na.fb  # pokud nema, staci smazat tuto radku
  googleplus: https://plus.google.com/+uzivatel.na.googleplus
  twitter: https://twitter.com/uzivatel.na.twitteru
  blog: http://blog.aktualne.cz/blogy/lukas-wagenknecht.php
  web: https://lukaswagenknecht.cz/
office:
  - address: Jiřího náměstí 39, 290 33  Poděbrady
    name: Poslanecká kancelář
    opening: "Pondělí 14:00 - 18:00, objednání návštěvy: kancelar-podebrady@pirati.cz nebo 778 111 462. Dne 18. 6. je z pracovních důvodů kancelář mimo provoz."
---

Jméno Příjmení (*1. ledna 1900) je to a to, a tak dál. Sem patří představení člověka, několik odstavců.

**Vzdělání/práce:** Studoval něco, teď dělá něco.

**Politik:** Třeba čemu se věnuje.

**Osobní:** Něco dalšího, měnit dle libosti, tady může být cokoliv. Není nutné, aby byly nadpisy tučně. Fakt jak chcete.

